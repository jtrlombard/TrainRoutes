﻿using NUnit.Framework;
using System.Collections.Generic;

namespace TrainRoutes.Test
{
    [TestFixture]
    class TestALL
    {
        [SetUp]
        public void Setup()
        {
            DAL.daRoutes.GetRoutes("Repository/trainroutes.txt");
        }

        [Test]
        public void CanCalcDistanceBetweenDirectRoutes()
        {
            // setup
            int testDistance = 6;
            string testStartStation = "D";
            string testEndStation = "E";

            //act
            int dist = ALL.TrainRouteCalcs.GetOneStopDistance(testStartStation, testEndStation);

            //assert
            Assert.AreEqual(dist, testDistance);
        }

        [Test]
        public void CanCalcTotalDistanceOfRoute()
        {
            // setup
            string testRoute = "abc";
            int testDistance = 9;

            //act
            int dist = ALL.TrainRouteCalcs.GetTotalRouteDistance(testRoute);

            //assert
            Assert.AreEqual(dist, testDistance);
        }

        [Test]
        public void CanFilterRoutesWithMaxStops()
        {
            // setup
            string testStartStation = "C";
            string testStopStation = "C";
            int maxStops = 3;
            int expectedRoutes = 2;

            //act
            List<string> routes = ALL.TrainRouteCalcs.FilterRoutesWithMaxStops(testStartStation, testStopStation, maxStops);

            //assert
            Assert.AreEqual(routes.Count, expectedRoutes);
        }

        [Test]
        public void CanFilterRoutesWithNumberStops()
        {
            // setup
            string testStartStation = "A";
            string testStopStation = "C";
            int numberStops = 4;
            int expectedRoutes = 3;

            //act
            List<string> routes = ALL.TrainRouteCalcs.FilterRoutesWithNumberOfStops(testStartStation, testStopStation, numberStops);

            //assert
            Assert.AreEqual(routes.Count, expectedRoutes);
        }
    }
}
