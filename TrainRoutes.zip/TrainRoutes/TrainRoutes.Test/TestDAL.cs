using NUnit.Framework;
using System.Collections.Generic;

namespace TrainRoutes.Test
{
    [TestFixture]
    public class Tests
    {
        private List<Models.Route> routes;
        private List<string> stations;

        [SetUp]
        public void Setup()
        {
            DAL.daRoutes.GetRoutes("Repository/trainroutes.txt");
            routes = DAL.daRoutes.Routes;
            stations = DAL.daRoutes.Stations;
        }

        [Test]
        public void CanLoadRouteTestData()
        {
            Assert.Greater(routes.Count, 0);
        }

        [Test]
        public void CanLoadstationData()
        {
            Assert.Greater(stations.Count, 0);
        }
    }
}