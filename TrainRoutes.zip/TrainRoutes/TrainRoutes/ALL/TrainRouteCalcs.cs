﻿using System;
using System.Collections.Generic;
using System.Text;
using TrainRoutes.DAL;
using TrainRoutes.Models;
using System.Linq;

namespace TrainRoutes.ALL
{
    public static class TrainRouteCalcs
    {
        /// <summary>
        /// Return direct route distances as per data
        /// </summary>
        /// <param name="start">Start Station</param>
        /// <param name="end">End Station</param>
        /// <returns>Distance</returns>
        public static int GetOneStopDistance(string start, string end)
        {
            Route r = daRoutes.Routes.Where(r => r.StartStation == start && r.EndStation == end).FirstOrDefault();
            if (r != null) return r.Distance;
            else return 0;
        }

        /// <summary>
        /// Calculate Total Route Distance
        /// </summary>
        /// <param name="route">ie. ABC or abc</param>
        /// <returns>Total distance</returns>
        public static int GetTotalRouteDistance(string route)
        {

            List<char> stations = route.ToUpper().ToList();
            int totalDist = 0;
            string start, stop;
            int totalStops = stations.Count - 1;
            for (int i = 0; i < totalStops; i++)
            {
                start = stations[i].ToString();
                stop = stations[i + 1].ToString();
                int dist = GetOneStopDistance(start, stop);
                if (dist == 0) // route does not exist
                {
                    totalDist = 0;
                    break;
                }
                totalDist += dist;
            }
            return totalDist;
        }

        
        /// <summary>
        /// Return all possible routes between start and end stations with no maore than max stops
        /// </summary>
        /// <param name="start">Start Station</param>
        /// <param name="end">End Station</param>
        /// <param name="maxStops">Maximum number of stops</param>
        /// <returns>Routes</returns>
        public static List<string> GetRouteCombos(string start, string end, int maxStops)
        {
            // Setup init start routes
            List<Route> startRoutes = daRoutes.GetAllRoutesStartingWith(start);
            List<string> combos = new List<string>();  // routeCombos
            foreach (Route r in startRoutes) combos.Add(r.StartStation + r.EndStation);

            // Use the start from position where last route combos where added
            int startPos = 0;
            int stopPos = combos.Count;

            for (int ii = 0; ii < maxStops; ii++)  // this is required to prevent endless loop like route CDCDCDCD...
            {
                List<string> newRoutes = new List<string>();
                for (int i = startPos; i < stopPos; i++)
                {
                    string nextStartStation = combos[i][combos[i].Length - 1].ToString();
                    List<Route> nextRoutes = daRoutes.GetAllRoutesStartingWith(nextStartStation);

                    foreach (Route r in nextRoutes)
                    {
                        string newRoute = combos[i] + r.EndStation;
                        newRoutes.Add(newRoute);
                    }
                }
                // Add new routes combos
                foreach (string s in newRoutes) combos.Add(s);

                // Setup start/stop position to read only latest added combos
                if (combos.Count > stopPos)
                {
                    startPos = stopPos;
                    stopPos = combos.Count;
                }
                else break;
            }

            // Filter route combos to only include routes with specified start and end stations
            List<string> finalResult = new List<string>();
            foreach (string s in combos)
            {
                if (s[0].ToString() == start && s[s.Length - 1].ToString() == end) finalResult.Add(s);
            }

            return finalResult;
        }

        /// <summary>
        /// Find routes from start to end with less or equal to maximum number of stops
        /// </summary>
        /// <param name="start">Start Station</param>
        /// <param name="end">End Station</param>
        /// <param name="maxStops">Maximum Stops</param>
        /// <returns>Routes</returns>
        public static List<string> FilterRoutesWithMaxStops(string start, string end, int maxStops)
        {
            List<string> combos = GetRouteCombos(start, end, maxStops);
            List<string> result = new List<string>();
            foreach (string s in combos)
            {
                if ((s.Length - 1) <= maxStops) result.Add(s);
            }
            return result;
        }

        /// <summary>
        /// Find routes from start to end with a specified number of stops
        /// </summary>
        /// <param name="start">Start Station</param>
        /// <param name="end">End Station</param>
        /// <param name="numberStops">Number of Stops</param>
        /// <returns>Routes</returns>
        public static List<string> FilterRoutesWithNumberOfStops(string start, string end, int numberStops)
        {
            List<string> combos = GetRouteCombos(start, end, numberStops);
            List<string> result = new List<string>();
            foreach (string s in combos)
            {
                if ((s.Length - 1) == numberStops) result.Add(s);
            }
            return result;
        }

        /// <summary>
        /// Find shotest distance routes from start to end
        /// /// </summary>
        /// <param name="start">Start Station</param>
        /// <param name="end">End Station</param>
        /// <param name="maxStops">Maximum Stops</param>
        /// <returns>Routes</returns>
        public static List<string> FilterRoutesWithShortestDistance(string start, string end, int maxLoops)
        {
            List<string> combos = GetRouteCombos(start, end, maxLoops);
            List<string> result = new List<string>();
            int shortestDist = int.MaxValue;
            foreach (string route in combos)
            {
                int dist = GetTotalRouteDistance(route);
                if (dist == shortestDist) result.Add(route + " Dist: " + dist);
                if (dist < shortestDist)
                {
                    result.Clear();
                    result.Add(route + " Dist: " + dist);
                    shortestDist = dist;
                }
            }
            return result;
        }

        /// <summary>
        /// Find all routes between start and end stations with distance lass max distance
        /// /// </summary>
        /// <param name="start">Start Station</param>
        /// <param name="end">End Station</param>
        /// <param name="maxStops">Maximum Stops</param>
        /// <param name="maxDistance">Maximum Distance</param>
        /// <returns>Routes</returns>
        public static List<string> FilterRoutesWithLessThanDistance(string start, string end, int maxLoops, int maxDistance)
        {
            List<string> combos = GetRouteCombos(start, end, maxLoops);
            List<string> result = new List<string>();
            foreach (string route in combos)
            {
                int dist = GetTotalRouteDistance(route);
                if (dist < maxDistance) result.Add(route + " Dist: " + dist);
            }
            return result;
        }

    }
}
