﻿using System.Collections.Generic;
using System.Linq;
using TrainRoutes.DAL;
using TrainRoutes.Models;
using TrainRoutes.ALL;

namespace TrainRoutes.ViewModels
{
    class vmRoutes
    {
        public List<Route> Routes { get; set; }
        public List<string> Stations { get; set; }

        public void GetRouteDistances()
        {
            daRoutes.GetRoutes("Repository/trainroutes.txt");
            Routes = daRoutes.Routes;
            if (daRoutes.Routes != null) Stations = daRoutes.GetAllStations();
        }

        public int GetOneStopDistance(string start, string end)
        {
            return TrainRouteCalcs.GetOneStopDistance(start, end);
        }

        public int GetRouteDistance(string route)
        {
            return TrainRouteCalcs.GetTotalRouteDistance(route);
        }

        public List<string> GetRoutesWithMaxStops(string start, string end, int maxStops)
        {
            return TrainRouteCalcs.FilterRoutesWithMaxStops(start, end, maxStops);
        }

        public List<string> GetRoutesWithNumberOfStops(string start, string end, int numberStops)
        {
            return TrainRouteCalcs.FilterRoutesWithNumberOfStops(start, end, numberStops);
        }

        public List<string> GetRoutesWithShortestDistance(string start, string end, int numberLoops)
        {
            return TrainRouteCalcs.FilterRoutesWithShortestDistance(start, end, numberLoops);
        }

        public List<string> GetRoutesWithLessThanDistance(string start, string end, int numberLoops, int maxDistance)
        {
            return TrainRouteCalcs.FilterRoutesWithLessThanDistance(start, end, numberLoops, maxDistance);
        }


    }

}
