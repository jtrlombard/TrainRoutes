﻿using System.Collections.Generic;
using System.IO;
using System.Linq;
using TrainRoutes.Models;


namespace TrainRoutes.DAL
{
    /// <summary>
    /// Retrieve route distance data from text file
    /// Assessment data is ranged A,B,C,D,E
    /// </summary>
    public static class daRoutes
    {
        public static List<Route> Routes { get; set; }
        public static List<string> Stations { get; set; }

        public static void GetRoutes(string filename)
        {
            Routes = new List<Route>();
            try
            {
                if (File.Exists(filename))
                {
                    string[] data = File.ReadAllLines(filename);
                    foreach (string s in data)
                    {
                        if (!string.IsNullOrEmpty(s))
                        {
                            string[] route = s.Split(',');
                            Route r = new Route();
                            r.StartStation = route[0].ToUpper();
                            r.EndStation = route[1].ToUpper();
                            if (int.TryParse(route[2], out int dist)) r.Distance = dist;
                            else throw new InvalidDataException();
                            Routes.Add(r);
                        }
                    }
                }
            }
            catch
            {
                // Text file cannot be processed
                Routes = null;
            }
            if (Routes != null) GetAllStations();
        }

        /// <summary>
        /// Get all the stations in the routes data
        /// </summary>
        public static List<string> GetAllStations()
        {
            Stations = new List<string>();
            foreach (Route r in Routes)
            {
                if (!Stations.Contains(r.StartStation)) Stations.Add(r.StartStation);
                if (!Stations.Contains(r.EndStation)) Stations.Add(r.EndStation);
            }
            return Stations;
        }

        /// <summary>
        /// Get all routes with specified start station
        /// </summary>
        /// <param name="start">Start Station</param>
        /// <returns>Routes</returns>
        public static List<Route> GetAllRoutesStartingWith(string start)
        {
            List<Route> routes = new List<Route>();
            foreach (Route r in daRoutes.Routes)
            {
                if (r.StartStation == start) routes.Add(r);
            }
            return routes;
        }

        


    }
}
