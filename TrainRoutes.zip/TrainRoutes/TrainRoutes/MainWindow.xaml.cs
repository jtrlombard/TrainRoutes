﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using TrainRoutes.DAL;
using TrainRoutes.Models;
using TrainRoutes.ViewModels;

namespace TrainRoutes
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private vmRoutes vm = new vmRoutes();

        public MainWindow()
        {
            vm.GetRouteDistances();
            InitializeComponent();
            InitView();
        }

        private void InitView()
        {

            if (vm.Routes != null && vm.Routes.Count > 0)
            {
                string routeResult = string.Empty;
                foreach (Route r in vm.Routes)
                {
                    routeResult += r.StartStation + r.EndStation + r.Distance + " ";
                }
                tbRoutes.Text = routeResult;

                cbOneStartDistance.ItemsSource = vm.Stations;
                cbOneStopDistance.ItemsSource = vm.Stations;
                cbOneStartDistance.SelectedIndex = 0;
                cbOneStopDistance.SelectedIndex = 1;

                cbMaxStartStations.ItemsSource = vm.Stations;
                cbMaxEndStations.ItemsSource = vm.Stations;
                cbMaxStartStations.SelectedIndex = 2; // init for assessment 6
                cbMaxEndStations.SelectedIndex = 2; // init for assessment 6
                txtMaxStops.Text = "3"; // init for assement 6

                cbNumberStartStations.ItemsSource = vm.Stations;
                cbNumberEndStations.ItemsSource = vm.Stations;
                cbNumberStartStations.SelectedIndex = 0; // init for assessment 7
                cbNumberEndStations.SelectedIndex = 2; // init for assessment 7
                txtNumberStops.Text = "4"; // init for assement 7

                cbShortestStartStations.ItemsSource = vm.Stations;
                cbShortestEndStations.ItemsSource = vm.Stations;
                cbShortestStartStations.SelectedIndex = 0; // init for assessment 8
                cbShortestEndStations.SelectedIndex = 2; // init for assessment 8
                txtShortestSearchLoops.Text = "4"; // init for assement 8

                cbAllStartStations.ItemsSource = vm.Stations;
                cbAllEndStations.ItemsSource = vm.Stations;
                cbAllStartStations.SelectedIndex = 2; // init for assessment 10
                cbAllEndStations.SelectedIndex = 2; // init for assessment 10
                txtAllSearchLoops.Text = "10"; // init for assement 10
                txtLessDistance.Text = "30";
            }
            else
            {
                tbRoutes.Text = "WARNING! No Routes Loaded";
                MessageBox.Show("No route data loaded!", "Error", MessageBoxButton.OK);
            }

        }

        private void btnDistanceCalc_Click(object sender, RoutedEventArgs e)
        {
            tbOneRouteDistance.Text = cbOneStartDistance.Text + cbOneStopDistance.Text;
            int dist = vm.GetOneStopDistance(cbOneStartDistance.Text, cbOneStopDistance.Text);
            if (dist == 0)
            {
                tbOneRouteDistance.Text = "NO ROUTE";
                tbOneDistanceDistance.Text = string.Empty;
            }
            else tbOneDistanceDistance.Text = dist.ToString();
        }

        private void btnAssessment1To5_Click(object sender, RoutedEventArgs e)
        {
            int dist = vm.GetRouteDistance(tbRoute.Text.ToUpper());
            if (dist == 0) tbRouteDistance.Text = "NO ROUTE";
            else tbRouteDistance.Text = dist.ToString();
        }

        private void btnAssessmnet6_Click(object sender, RoutedEventArgs e)
        {
            lstRoutesMaxStops.ItemsSource = null;
            lstRoutesMaxStops.Items.Clear();
            if (int.TryParse(txtMaxStops.Text, out int maxStops))
            {
                if (maxStops < 1) MessageBox.Show("Max Stops is not a Valid Number.", "Warning", MessageBoxButton.OK);
                else
                { 
                    List<string> routes = vm.GetRoutesWithMaxStops(cbMaxStartStations.Text, cbMaxEndStations.Text, maxStops);
                    if (routes.Count == 0)
                    {
                        tbRoutesFoundWithMaxStops.Text = string.Empty;
                        lstRoutesMaxStops.Items.Add("NO ROUTES");
                    }
                    else
                    {
                        tbRoutesFoundWithMaxStops.Text = routes.Count.ToString();
                        lstRoutesMaxStops.ItemsSource = routes;
                    }
                }
            }
            else MessageBox.Show("Max Stops is not a Valid Number.", "Warning", MessageBoxButton.OK);
        }

        private void btnAssessment7_Click(object sender, RoutedEventArgs e)
        {
            lstRoutesNumberStops.ItemsSource = null;
            lstRoutesNumberStops.Items.Clear();
            if (int.TryParse(txtNumberStops.Text, out int numberStops))
            {
                if (numberStops < 1) MessageBox.Show("Number of Stops is not a Valid Number.", "Warning", MessageBoxButton.OK);
                else 
                {
                    List<string> routes = vm.GetRoutesWithNumberOfStops(cbNumberStartStations.Text, cbNumberEndStations.Text, numberStops);
                    if (routes.Count == 0)
                    {
                        tbRoutesFoundWithNumberStops.Text = string.Empty;
                        lstRoutesNumberStops.Items.Add("NO ROUTES");
                    }
                    else
                    {
                        tbRoutesFoundWithNumberStops.Text = routes.Count.ToString();
                        lstRoutesNumberStops.ItemsSource = routes;
                    }
                }
            }
            else MessageBox.Show("Number of Stops is not a Valid Number.", "Warning", MessageBoxButton.OK);
        }
        private void btnAssessment8To9_Click(object sender, RoutedEventArgs e)
        {
            lstRoutesShortestDistance.ItemsSource = null;
            lstRoutesShortestDistance.Items.Clear();
            if (int.TryParse(txtShortestSearchLoops.Text, out int maxStops))
            {
                if (maxStops < 1) MessageBox.Show("Max Stops is not a Valid Number.", "Warning", MessageBoxButton.OK);
                else
                {
                    List<string> routes = vm.GetRoutesWithShortestDistance(cbShortestStartStations.Text, cbShortestEndStations.Text, maxStops);
                    if (routes.Count == 0)
                    {
                        tbRoutesFoundWithShortestDistance.Text = string.Empty;
                        lstRoutesShortestDistance.Items.Add("NO ROUTES");
                    }
                    else
                    {
                        tbRoutesFoundWithShortestDistance.Text = routes.Count.ToString();
                        lstRoutesShortestDistance.ItemsSource = routes;
                    }
                }
            }
            else MessageBox.Show("Max of Stops is not a Valid Number.", "Warning", MessageBoxButton.OK);
        }

        private void btnAssessment10_Click(object sender, RoutedEventArgs e)
        {
            lstAllRoutesWithinDistance.ItemsSource = null;
            lstAllRoutesWithinDistance.Items.Clear();
            if (int.TryParse(txtAllSearchLoops.Text, out int maxLoops))
            {
                if (maxLoops < 1) MessageBox.Show("Max Stops is not a Valid Number.", "Warning", MessageBoxButton.OK);
                else
                {
                    if (int.TryParse(txtLessDistance.Text, out int maxDistance))
                    {
                        if (maxDistance < 1) MessageBox.Show("Max Stops is not a Valid Number.", "Warning", MessageBoxButton.OK);
                        else
                        {
                            List<string> routes = vm.GetRoutesWithLessThanDistance(cbAllStartStations.Text, cbAllEndStations.Text, maxLoops, maxDistance);
                            if (routes.Count == 0)
                            {
                                tbAllRoutesWithinDistance.Text = string.Empty;
                                lstAllRoutesWithinDistance.Items.Add("NO ROUTES");
                            }
                            else
                            {
                                tbAllRoutesWithinDistance.Text = routes.Count.ToString();
                                lstAllRoutesWithinDistance.ItemsSource = routes;
                            }
                        }
                    }
                    else MessageBox.Show("Less Distance not a Valid Number.", "Warning", MessageBoxButton.OK);
                }
            }
            else MessageBox.Show("Max of Stops is not a Valid Number.", "Warning", MessageBoxButton.OK);
        }
    }
}
