﻿namespace TrainRoutes.Models
{
    public class Route
    {
        public string StartStation { get; set; }
        public string EndStation { get; set; }
        public int Distance { get; set; }
    }
}
